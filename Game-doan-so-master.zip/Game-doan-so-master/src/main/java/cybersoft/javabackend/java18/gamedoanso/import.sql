insert into player(username, password, name)
values('admin', '1234', 'Administrator');
