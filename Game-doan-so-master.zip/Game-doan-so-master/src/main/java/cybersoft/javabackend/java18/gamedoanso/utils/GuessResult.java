package cybersoft.javabackend.java18.gamedoanso.utils;

public enum GuessResult {
    GREATER,
    SMALLER,
    PINGO
}
